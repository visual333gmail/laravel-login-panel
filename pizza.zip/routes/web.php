<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/pizza-order', [App\Http\Controllers\HomeController::class, 'pizza_order'])->name('pizza-order');
Route::post('/place-order', [App\Http\Controllers\HomeController::class, 'place_order'])->name('place-order');
Route::get('/orders', [App\Http\Controllers\HomeController::class, 'order_item_list'])->name('orders');
