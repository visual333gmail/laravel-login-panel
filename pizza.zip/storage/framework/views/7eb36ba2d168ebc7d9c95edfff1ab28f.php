<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <!-- <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php echo e(__('You are logged in!')); ?>

                    </div> -->
                </div>
                <div class="card">
            <div class="card-header"><?php echo e(__('Pizza Order Form')); ?></div>
                <form action="<?php echo e(route('place-order')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="name">Your Name:</label>
                    <input type="text" id="name" name="name" required value="<?php echo e(Auth::user()->name); ?>">
                    
                    <br>
                    <br>
                    <label for="pizza">Pizza:</label>
                    <select id="pizza" name="pizza" required>
                        <option value="">Select pizza please</option>
                        <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option pizza_price="<?php echo e($value->price); ?>" value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?> - <?php echo e($value->price); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Add more options as needed -->
                    </select>

                    <br>
                    <br>
                    <label for="size">Size:</label>
                    <select id="pizza_size" name="pizza_size" required disabled>
                    <option value="">Select size please</option>
                        <?php $__currentLoopData = $pizzas_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option pizza_size_price="<?php echo e($value->price); ?>" value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?> - <?php echo e($value->price); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                    <br>
                    <br>
                    <label for="size">Toppings:</label>
                    <select id="pizza_toppings" name="pizza_toppings" required disabled>
                    <option value="">Select toppings please</option>
                        <?php $__currentLoopData = $pizzas_toppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option pizza_toppings_price="<?php echo e($value->price); ?>" value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?> - <?php echo e($value->price); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <!-- Add more toppings checkboxes -->
                    <br>
                    <br>
                    <label for="name">Total Price</label>
                    <input type="text" id="total_price" name="total_price" required>
                    <button type="submit">Place Order</button>
                    <br>
                    <br>
                </form>
            </div>
            </div>
        </div>
    

        
    </div>
    
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
    console.log('hello');
    var pizzaprice = 0;
    var pizza_size_price = 0;
    var pizza_toppings_price = 0;
    
    $("#pizza").change(function(){
        pizza_name = $('option:selected',this).text();
        pizza_price =  $('option:selected',this).attr('pizza_price');
        $('#total_price').val(pizza_price);
        console.log(pizza_price);

        $("#pizza_size").removeAttr('disabled');
        if($('#pizza').find(":selected").attr('pizza_price') == undefined){
            $("#pizza_size").attr('disabled','disabled');
            $("#pizza_toppings").attr('disabled','disabled');
            $("#pizza_size").val('');
            $("#pizza_toppings").val('');
            $("#total_price").val('');

        }
    });

    $("#pizza_size").change(function(){
        $("#pizza_toppings").removeAttr('disabled');
        pizza_size = $('option:selected',this).text();
        pizza_price = parseFloat($('#pizza').find(":selected").attr('pizza_price')).toFixed(2);
        pizza_size_price =  parseFloat($('option:selected',this).attr('pizza_size_price')).toFixed(2);
        
        $('#total_price').val((parseFloat(pizza_price) + parseFloat(pizza_size_price)). toFixed(2));
        // console.log(parseFloat(pizza_price). toFixed(2));
        // console.log(parseFloat(pizza_size_price). toFixed(2));

        
        if($('#pizza_size').find(":selected").attr('pizza_size_price') == undefined){
            $("#pizza_toppings").attr('disabled','disabled');
            $("#pizza_size").val('');
            $("#pizza_toppings").val('');
            $("#total_price").val('');
        }
    });  

    $("#pizza_toppings").change(function(){   
        pizza_toppings = $('option:selected',this).text();
        pizza_price = parseFloat($('#pizza').find(":selected").attr('pizza_price')).toFixed(2);
        pizza_size_price =  parseFloat($('#pizza_size').find(":selected").attr('pizza_size_price')).toFixed(2);
        pizza_toppings_price =  parseFloat($('option:selected',this).attr('pizza_toppings_price')).toFixed(2);
        $('#total_price').val((parseFloat(pizza_price) + parseFloat(pizza_size_price) + parseFloat(pizza_toppings_price)).toFixed(2));
        // console.log(( parseFloat(pizza_price+pizza_size_price+pizza_toppings_price).toFixed(2) ));
        if($('#pizza_toppings').find(":selected").attr('pizza_toppings_price') == undefined){
            $("#pizza_toppings").val('');
            $('#total_price').val((parseFloat(pizza_price) + parseFloat(pizza_size_price)).toFixed(2));
        }

        console.log(parseFloat(pizza_price). toFixed(2));
        console.log(parseFloat(pizza_size_price). toFixed(2));
        console.log(parseFloat(pizza_toppings_price). toFixed(2));

    });
</script>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pizza-test\resources\views/home.blade.php ENDPATH**/ ?>