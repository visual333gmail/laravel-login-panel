<?php $__env->startSection('content'); ?>
   <div class="container">
      <div class="row page-titles">
         <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item active"><a href="/">Home</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)">Orders</a></li> -->
         </ol>
      </div>
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-header">
                  <h4 class="card-title">Pizza Order List</h4>
                  <a href="<?php echo e(route('pizza-order')); ?>" class="btn btn-primary">Create Order</a>
               </div>
               <div class="card-body">
                  <table class="table">
                     <thead>
                        <tr>
                           <th scope="col">Customer </th>
                           <th scope="col">Pizza : Rs</th>
                           <th scope="col">Size : Rs</th>
                           <th scope="col">Topping : Rs</th>
                           <th scope="col">Total Price</th>
                        </tr>
                     </thead>
                     <tbody>
                           <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php 
                           // dd($value->pizza_size->first()->name); 
                           ?>
                              <tr>
                                 <td class="range2" > <?php echo e($value->customer->name); ?></span></td>
                                 <td class="range" ><?php echo e($value->pizzas->first()->name); ?> : <b><?php echo e($value->pizzas->first()->price); ?></b></td>
                                 <td class="range1"><?php echo e($value->pizza_size->first()->name); ?> : <b><?php echo e($value->pizza_size->first()->price); ?></b></span></td>
                                 <td class="range1"><?php echo e($value->pizza_toppings->first()->name); ?> : <b><?php echo e($value->pizza_toppings->first()->price); ?></b></td>
                                 <td class="range1"><span style="font-size:12px;" class="badge light badge-success"><?php echo e($value->total_price); ?></span></td>
                              </tr>       
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pizza-test\resources\views/orders.blade.php ENDPATH**/ ?>