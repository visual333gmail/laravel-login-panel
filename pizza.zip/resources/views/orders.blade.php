@extends('layouts.app')
@section('content')
   <div class="container">
      <div class="row page-titles">
         <ol class="breadcrumb">
            <!-- <li class="breadcrumb-item active"><a href="/">Home</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)">Orders</a></li> -->
         </ol>
      </div>
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
               <div class="card-header">
                  <h4 class="card-title">Pizza Order List</h4>
                  <a href="{{ route('pizza-order') }}" class="btn btn-primary">Create Order</a>
               </div>
               <div class="card-body">
                  <table class="table">
                     <thead>
                        <tr>
                           <th scope="col">Customer </th>
                           <th scope="col">Pizza : Rs</th>
                           <th scope="col">Size : Rs</th>
                           <th scope="col">Topping : Rs</th>
                           <th scope="col">Total Price</th>
                        </tr>
                     </thead>
                     <tbody>
                           @foreach($orders as $value)
                           <?php 
                           // dd($value->pizza_size->first()->name); 
                           ?>
                              <tr>
                                 <td class="range2" > {{$value->customer->name}}</span></td>
                                 <td class="range" >{{$value->pizzas->first()->name}} : <b>{{$value->pizzas->first()->price}}</b></td>
                                 <td class="range1">{{$value->pizza_size->first()->name}} : <b>{{$value->pizza_size->first()->price}}</b></span></td>
                                 <td class="range1">{{$value->pizza_toppings->first()->name}} : <b>{{$value->pizza_toppings->first()->price}}</b></td>
                                 <td class="range1"><span style="font-size:12px;" class="badge light badge-success">{{$value->total_price}}</span></td>
                              </tr>       
                           @endforeach 
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
@endsection   