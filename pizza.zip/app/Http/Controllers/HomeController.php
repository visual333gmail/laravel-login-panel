<?php

namespace App\Http\Controllers;

use App\Models\OrderItems;
use App\Models\Pizzas;
use App\Models\PizzaSizes;
use App\Models\PizzaToppings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // return view('home');
        return redirect( route('orders'));
    }

    public function pizza_order()
    {
     $pizzas = Pizzas::all();
     $pizzas_sizes = PizzaSizes::all();
     $pizzas_toppings = PizzaToppings::all();
    //  dd($pizzas);
        return view('home',compact(
            'pizzas','pizzas_sizes','pizzas_toppings'
            
        ));
    }

    public function order_item_list()
    {
     $orders = OrderItems::all();
    //  dd($orders);
        return view('orders',compact(
            'orders'
            
        ));
    }

    public function place_order(Request $request)
    {
        // dd($request);
        $order_place = new OrderItems();
        $order_place->customer_id = Auth::user()->id; 
        $order_place->employee_id = null; 
        $order_place->pizza_id = $request->pizza; 
        $order_place->size_id = $request->pizza_size;  
        $order_place->topping_id = $request->pizza_toppings; 
        $order_place->total_price = $request->total_price; 
        $order_place->save(); 
        // return view('home',compact(
        //     'pizzas','pizzas_sizes','pizzas_toppings'
            
        // ));
        return redirect(route('orders'));
    }
}
